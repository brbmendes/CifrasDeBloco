﻿using CifraDeBloco.source;
using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace CifraDeBloco
{
    class Program
    {
        static void Main(string[] args)
        {
            Auxiliar classeAuxiliar = new Auxiliar();

            int operacao = 0;

            while (true)
            {
                Console.WriteLine("Informe a operação desejada: ");
                Console.WriteLine("1 - Cifrar texto entrada");
                Console.WriteLine("2 - Decifrar texto entrada");
                //Console.WriteLine("3 - Cifrar texto manual");
                //Console.WriteLine("4 - Decifrar texto manual");
                Console.WriteLine("5 - Cifra e Decifra texto manual - Op. Mode: CBC");
                Console.WriteLine("6 - Sair");

                operacao = int.Parse(Console.ReadLine());
                if (operacao == 1)
                {
                    // Cifrar
                    Console.WriteLine("");

                    string cripto = "AES";
                    // Define o arquivo de entrada e converte para um array
                    string caminho = classeAuxiliar.EscolherEntrada("cipher");
                    if (caminho.Equals("voltar"))
                    {
                        Console.WriteLine("");
                        continue;
                    }
                    string[] entrada = classeAuxiliar.LerEntrada(caminho);

                    // Obtem o vetor de inicializacao
                    byte[] iv = classeAuxiliar.ObterVetorInicializacao(entrada);

                    // obtem o tipo de modo de operacao, a chave e o texto SEM o vetor de inicializacao
                    string tipo = string.Empty;
                    string chave = string.Empty;
                    string texto = string.Empty;
                    classeAuxiliar.ObterInfoEntrada(entrada, out tipo, out chave, out texto);

                    using (AesManaged aes = new AesManaged())
                    {
                        // Define o modo de operação e padding, se necessário
                        if (tipo.Equals("cbc"))
                        {
                            aes.Mode = CipherMode.CBC;
                            aes.Padding = PaddingMode.PKCS7;
                        }
                        else
                        {
                            // Seria o CTR
                        }

                        // Converte a chave em hexa para a chave no formato AES
                        aes.Key = classeAuxiliar.StringToByteArray(chave);

                        // Obtém o vetor de inicialização (IV) no formato AES
						aes.IV = iv;
						
                        ICryptoTransform encryptor = aes.CreateEncryptor();

                        MemoryStream ms = new MemoryStream();

                        // Cifra o texto
                        byte[] ciphered = null;

                        using (CryptoStream cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                        {
                            // Create StreamWriter and write data to a stream    
                            using (StreamWriter sw = new StreamWriter(cs))
                            {
                                sw.Write(texto);
                            }
                            ciphered = ms.ToArray();
                        }

                        classeAuxiliar.ImprimirSaidaCifrar(tipo, chave, texto, ciphered);
                    }
                }
                else if (operacao == 2)
                {
                    // Decifrar
                    Console.WriteLine("");

                    string cripto = "AES";
                    // Define o arquivo de entrada e converte para um array
                    string caminho = classeAuxiliar.EscolherEntrada("decipher");
                    if (caminho.Equals("voltar"))
                    {
                        Console.WriteLine("");
                        continue;
                    }
                    string[] entrada = classeAuxiliar.LerEntrada(caminho);

                    // Obtem o vetor de inicializacao
                    byte[] iv = classeAuxiliar.ObterVetorInicializacao(entrada);

                    // obtem o tipo de modo de operacao, a chave e o texto SEM o vetor de inicializacao
                    string tipo = string.Empty;
                    string chave = string.Empty;
                    string texto = string.Empty;
                    classeAuxiliar.ObterInfoEntrada(entrada, out tipo, out chave, out texto);

                    using (AesManaged aes = new AesManaged())
                    {
                        // Define o modo de operação e padding, se necessário
                        if (tipo.Equals("cbc"))
                        {
                            aes.Mode = CipherMode.CBC;
                            aes.Padding = PaddingMode.PKCS7;
                        }
                        else
                        {
                            // Seria o CTR
                        }

                        // Converte a chave em hexa para a chave no formato AES
                        aes.Key = classeAuxiliar.StringToByteArray(chave);

                        // Obtém o vetor de inicialização (IV) no formato AES
                        aes.IV = iv;

                        ICryptoTransform decryptor = aes.CreateDecryptor();

                        MemoryStream ms = new MemoryStream();

                        // Cifra o texto
                        byte[] ciphered = null;

                        using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Write))
                        {
                            // Create StreamWriter and write data to a stream    
                            using (StreamWriter sw = new StreamWriter(cs))
                            {
                                sw.Write(texto);
                            }
                            ciphered = ms.ToArray();
                        }

                        classeAuxiliar.ImprimirSaidaCifrar(tipo, chave, texto, ciphered);
                    }
                    //    // Decifrar
                    //    Console.WriteLine("");

                    //    string cripto = "AES";

                    //    // Define o arquivo de entrada e converte para um array
                    //    string caminho = classeAuxiliar.EscolherEntrada("decipher");
                    //    if (caminho.Equals("voltar"))
                    //    {
                    //        Console.WriteLine("");
                    //        continue;
                    //    }
                    //    string[] entrada = lerEntrada(caminho);

                    //    // Obtem o vetor de inicializacao
                    //    string vetorInicializacao = obterVetorInicializacao(entrada);

                    //    // obtem o tipo de modo de operacao, a chave e o texto SEM o vetor de inicializacao
                    //    string tipo = obterInfo(entrada, "tipo");
                    //    string chave = obterInfo(entrada, "chave");
                    //    string texto = obterInfo(entrada, "texto");

                    //    // Converte o vetor de inicialização em bytes, e obtem o ivSpec
                    //    byte[] iv = AES.toByteArray(vetorInicializacao);
                    //    IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);

                    //    // Converte a chave em bytes, e obtem a keySpec
                    //    SecretKeySpec sKeySpec = AES.getSecretKey(chave);
                    //    //byte[] byteChave = AES.toByteArray(chave);
                    //    //SecretKeySpec sKeySpec = new SecretKeySpec(byteChave, 0, byteChave.length, "AES");

                    //    // Define o modo de operação e o padding, se necessário
                    //    if (tipo.Equals("cbc"))
                    //    {
                    //        cripto = "AES/CBC/PKCS5Padding";
                    //    }
                    //    else
                    //    {
                    //        cripto = "AES/CTR/NoPadding";
                    //    }

                    //    Cipher cipher = Cipher.getInstance(cripto);

                    //    // Inicializa o cipher passando a chave e, se necessário, o vetor de inicializacao
                    //    if (tipo.Equals("cbc"))
                    //    {
                    //        cipher.init(Cipher.ENCRYPT_MODE, sKeySpec, ivParameterSpec);
                    //    }
                    //    else
                    //    {
                    //        cipher.init(Cipher.ENCRYPT_MODE, sKeySpec);
                    //    }

                    //    // Decifra o texto
                    //    byte[] deciphered = cipher.doFinal(AES.toByteArray(texto));

                    //classeAuxiliar.ImprimirSaidaDecifrar(tipo, chave, texto, deciphered);
                }
                else if (operacao == 3)
                {
                    //    Console.WriteLine("");
                    //    Console.WriteLine("Digite a senha:");
                    //    Console.WriteLine("");
                    //    Scanner scan = new Scanner(System.in);

                    //    string senha = scan.nextLine();

                    //    Console.WriteLine("");
                    //    Console.WriteLine("Digite o texto a ser cifrado:");
                    //    string texto = scan.nextLine();

                    //    SecretKeySpec sKeySpec = AES.getSecretKey(senha);

                    //    Cipher cipher = Cipher.getInstance("AES");

                    //    cipher.init(Cipher.ENCRYPT_MODE, sKeySpec);

                    //    byte[] ciphered = cipher.doFinal(texto.getBytes());

                    //classeAuxiliar.ImprimirSaidaCifrarManual(senha, texto, ciphered);
                    //    Console.WriteLine("");
                }
                else if (operacao == 4)
                {
                    //    Console.WriteLine("Digite a senha:");
                    //    Console.WriteLine("");
                    //    Scanner scan = new Scanner(System.in);

                    //    string senha = scan.nextLine();

                    //    Console.WriteLine("Digite o texto a ser decifrado:");
                    //    string texto = scan.nextLine();

                    //    SecretKeySpec sKeySpec = AES.getSecretKey(senha);

                    //    Cipher cipher = Cipher.getInstance("AES");

                    //    cipher.init(Cipher.DECRYPT_MODE, sKeySpec);

                    //    byte[] deciphered = cipher.doFinal(AES.toByteArray(texto));

                    //classeAuxiliar.ImprimirSaidaDecifrarManual(senha, texto, deciphered);
                    //    Console.WriteLine("");
                }
                else if (operacao == 5)
                {
                    //    //break;
                    //    Console.WriteLine("");
                    //    Console.WriteLine("Digite a senha:");
                    //    Console.WriteLine("");
                    //    Scanner scan = new Scanner(System.in);

                    //    string senha = scan.nextLine();
                    //    SecretKeySpec sKeySpec = AES.getSecretKey(senha);

                    //    Console.WriteLine("");
                    //    Console.WriteLine("Digite o texto a ser cifrado:");
                    //    string texto = scan.nextLine();

                    //    string vetorInicializacao = "4e657874205468757273646179206f6e";
                    //    byte[] iv = AES.toByteArray(vetorInicializacao);
                    //    IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);


                    //    Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");

                    //    cipher.init(Cipher.ENCRYPT_MODE, sKeySpec, ivParameterSpec);

                    //    byte[] ciphered = cipher.doFinal(texto.getBytes());

                    //classeAuxiliar.ImprimirSaidaCifrarManual(senha, texto, ciphered);

                    //    Console.WriteLine("Digite o texto a ser decifrado:");
                    //    texto = scan.nextLine();

                    //    cipher.init(Cipher.DECRYPT_MODE, sKeySpec, ivParameterSpec);

                    //    byte[] deciphered = cipher.doFinal(AES.toByteArray(texto));

                    //classeAuxiliar.ImprimirSaidaDecifrarManual(senha, texto, deciphered);
                }
                else if (operacao == 6)
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Operação inválida\n");
                }
            }

            classeAuxiliar.EncerrarPrograma();
        }
    }
}

