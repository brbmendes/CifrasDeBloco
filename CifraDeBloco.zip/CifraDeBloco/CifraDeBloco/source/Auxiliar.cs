﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace CifraDeBloco.source
{
    public class Auxiliar
    {

        /// <summary>
        /// Converter array de bytes para string em hexadecimal
        /// </summary>
        public String ByteArrayToHexString(byte[] array)
        {
            var hexString = BitConverter.ToString(array);
            hexString = hexString.Replace("-", "");
            return hexString;
        }


        /// <summary>
        /// Converter uma string em hexadecimal para um array de bytes
        /// </summary>
        public byte[] StringToByteArray(String s)
        {
            byte[] ba = Encoding.UTF8.GetBytes(s);
            return ba;
        }

        /// <summary>
        /// Converter um array de bytes em hexadecimal para uma string
        /// </summary>
        public String ByteArrayToString(byte[] array)
        {
            return Encoding.UTF8.GetString(array);
        }

        /// <summary>
        /// Encerra o programa.
        /// </summary>
        public void EncerrarPrograma()
        {
            Console.WriteLine("");
            Console.WriteLine("Encerrando o programa.");
            Console.ReadLine();
            System.Environment.Exit(0);
        }

        /// <summary>
        /// Exibe na tela a lista de opções de arquivo de entrada
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public string EscolherEntrada(string type)
        {
            int? operacao = -1;
            string path = string.Empty;
            while (!operacao.HasValue || operacao.Value < 0 || operacao.Value > 8 || operacao == null)
            {
                Console.WriteLine("Escolha um arquivo de entrada: ");

                if (type.ToLower().Equals("decipher"))
                {
                    Console.WriteLine("0 - voltar ");
                    Console.WriteLine("1 - tarefa 1 ");
                    Console.WriteLine("2 - tarefa 2 ");
                    Console.WriteLine("3 - tarefa 3 ");
                    Console.WriteLine("4 - tarefa 4 ");
                    //Console.WriteLine("8 - tarefa 8 ");
                }
                else
                {
                    Console.WriteLine("0 - voltar ");
                    Console.WriteLine("5 - tarefa 5 ");
                    Console.WriteLine("6 - tarefa 6 ");
                    //Console.WriteLine("7 - tarefa 7 ");
                }
                Console.WriteLine("");
                int tmp = 0;
                if (int.TryParse(Console.ReadLine(), out tmp))
                {
                    switch (tmp)
                    {
                        case 1:
                            path = "inputs/tarefa_1.txt";
                            operacao = 1;
                            break;
                        case 2:
                            path = "inputs/tarefa_2.txt";
                            operacao = 2;
                            break;
                        case 3:
                            path = "inputs/tarefa_3.txt";
                            operacao = 3;
                            break;
                        case 4:
                            path = "inputs/tarefa_4.txt";
                            operacao = 4;
                            break;
                        case 5:
                            path = "inputs/tarefa_5.txt";
                            operacao = 5;
                            break;
                        case 6:
                            path = "inputs/tarefa_6.txt";
                            operacao = 6;
                            break;
                        case 7:
                            path = "inputs/tarefa_7.txt";
                            operacao = 7;
                            break;
                        case 8:
                            path = "inputs/tarefa_8.txt";
                            operacao = 8;
                            break;
                        case 0:
                            path = "voltar";
                            operacao = 0;
                            break;
                        default:
                            Console.WriteLine("Opção inválida.");
                            Console.WriteLine();
                            break;

                    }

                }
                else
                {
                    Console.WriteLine("Opção inválida.");
                    Console.WriteLine();
                }
            }
            return path;
        }

        /// <summary>
        /// Le um arquivo de entrada e retorna um array com cada linha do arquivo
        /// </summary>
        /// <param name="arquivoEntrada"></param>
        /// <returns></returns>
        public string[] LerEntrada(string arquivoEntrada)
        {
            return File.ReadAllLines(arquivoEntrada);
        }

        /// <summary>
        /// Obtém as informações (tipo, chave e texto) de uma entrada
        /// </summary>
        /// <param name="array"></param>
        /// <param name="tipo"></param>
        /// <param name="chave"></param>
        /// <param name="texto"></param>
        public void ObterInfoEntrada(String[] array, out string tipo, out string chave, out string texto)
        {
            String[] linhas = null;

            linhas = array[0].Split(" ");
            tipo = linhas[0].Split("_")[0];

            linhas = array[0].Split(" ");
            chave = linhas[1];

            linhas = array[1].Split(" ");
            texto = linhas[1].Substring(16);
        }

        /// <summary>
        /// Obtém o vetor de inicialização a partir da entrada transformada em um array de strings
        /// </summary>
        /// <param name="entrada"></param>
        /// <returns></returns>
        public byte[] ObterVetorInicializacao(string[] entrada)
        {
            String textoCifrado = entrada[1].Split(" ")[1];
			byte[] byteCifrado = StringToByteArray(textoCifrado);
			byte[] iv = new byte[128];
            Array.Copy(byteCifrado,0,iv,0,128);
			return iv;
        }

        public void ImprimirSaidaCifrar(string tipo, string chave, string texto, byte[] ciphered)
        {
            Console.WriteLine("Tipo: " + tipo.ToUpper());
            Console.WriteLine("Chave: " + chave);
            Console.WriteLine("Texto decifrado: " + texto);
            Console.WriteLine("Texto cifrado: " + ByteArrayToHexString(ciphered));
            Console.WriteLine("");
        }

        public void ImprimirSaidaDecifrar(string tipo, string chave, string texto, byte[] deciphered)
        {
            Console.WriteLine("Tipo: " + tipo.ToUpper());
            Console.WriteLine("Chave: " + chave);
            Console.WriteLine("Texto cifrado: " + texto);
            Console.WriteLine("Texto decifrado: " + ByteArrayToString(deciphered));
            Console.WriteLine("");
        }

        public void ImprimirSaidaCifrarManual(string senha, string texto, byte[] ciphered)
        {
            Console.WriteLine("Senha: " + senha);
            Console.WriteLine("Texto decifrado: " + texto);
            Console.WriteLine("Texto cifrado: " + ByteArrayToHexString(ciphered));
            Console.WriteLine("");
        }

        public void ImprimirSaidaDecifrarManual(string senha, string texto, byte[] deciphered)
        {
            Console.WriteLine("Senha: " + senha);
            Console.WriteLine("Texto cifrado: " + texto);
            Console.WriteLine("Texto decifrado: " + ByteArrayToString(deciphered));
        }
    }
}
